import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';



function TaskComponent({ tsks , onDelete , id}) {

  const handleDelete = () => {
    onDelete(id);
  };
  return (
    // Display after entering the task
    <div className="task py-1 mx-5">
      <div>
        <p> {tsks}</p>
        
      </div>

      <button className='btn' onClick={handleDelete}><i class="fa-solid fa-trash"></i></button>
      {/* <button className='btn' onClick={handleDelete}>X</button> */}


    </div>
  );
}
// Function component representing the Main App
function App() {

  const [tasks, setTasks] = useState([]);

//store the value of the new task input field
  const [newTask, setNewTask] = useState('');
  

  // Function to handle adding new task
  const handleSubmit = async event => {
    event.preventDefault();

    try {
      await fetch('http://localhost:5000/get/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tsks: newTask })
      });

      // Fetch the updated data after the POST request to get the latest tasks
      fetchData();
      
      
    } catch (error) {
      console.error(error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:5000/get/tasks');
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    fetchData(); // Fetch data once when the component mounts
  }, []);
  
  
  


 // Function to handle deletion of tasks
 const handleDeleteTask = async (id) => {
  try {
    await fetch(`http://localhost:5000/get/tasks/${id}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    console.log("Task with ID", id, "is deleted.");

   
    setTasks(tasks.filter((task) => task.id !== id));
  } catch (error) {
    console.error("Error deleting task:", error);
  }
};




  return (
    // component
    <body>
      <div className='container mt-3'>
        <div className='row title tsk d-flex justify-content-center m-3'>
          TO DO PRO
        </div>
          
    
        <form onSubmit={handleSubmit}>
          <div className="row d-flex align-items-center justify-content-center m-5 mx-1">
            
            <div className='enter col-3 p-2'>
              Enter the task
            </div>
            <input
              className='col-5 p-2 input'
              type="text"
              name="data"
              placeholder='Enter your task'
              value={newTask}
              onChange={event => setNewTask(event.target.value)}
            />
            <button className='col-3 add-button ms-1' type="submit">Add Task</button>
            
          </div>
          
        </form>
      
        </div>

        {
  /* Renders TaskComponent */
}

        {tasks.map((task,index) => (
          <TaskComponent key={index}id={task.id} tsks={task.tsks}
          onDelete={handleDeleteTask} // Pass the onDelete function
           />
        ))}
      
    </body>
  );
}

export default App;
